# Adding true cloud storage (optional future work)

The current extension uses `chrome.storage.local` / `chrome.storage.sync`,
which is enough for most people and requires no backend or account system.
If you outgrow that (huge snippet libraries, syncing across different
browsers or accounts, sharing snippets with a team), here's the shape of
what a real cloud backend would take:

## Option A — Firebase (fastest to stand up)

1. Create a Firebase project, enable **Firestore** and **Authentication**
   (Google sign-in is simplest for a browser extension).
2. Add `"identity"` to `permissions` in `manifest.json` and use
   `chrome.identity.getAuthToken` (Chrome/Edge) to sign the user in.
3. Replace the `chrome.storage.*` calls in `sidepanel.js` / `background.js`
   with Firestore reads/writes, keyed by the signed-in user's UID.
4. Keep `chrome.storage.local` as an offline cache so the panel still works
   without a network connection, and sync in the background when it's back.

## Option B — Supabase (open-source, self-hostable)

Same shape as Option A, but using Supabase's JS client and Row Level
Security policies scoped to `auth.uid()` instead of Firebase Auth/Firestore.

## Things to design carefully

- **Conflict resolution**: if the same snippet is edited/deleted on two
  devices before syncing, decide on last-write-wins vs. merge.
- **Auth UX**: a browser extension side panel is a small surface — keep
  sign-in to one click (OAuth popup), don't build a full login form.
- **Privacy**: be upfront in the README and store listing about what data
  leaves the device once a real backend is involved — this is the main
  trade-off against the current sync-storage-only approach.
- **manifest permissions**: a real backend needs `host_permissions` for your
  API domain, which triggers an extra install-time permission prompt.

This is intentionally left unimplemented in v1.0.0 so the extension stays
simple, free to run, and doesn't require anyone to trust a third-party
server with their clipboard history.
